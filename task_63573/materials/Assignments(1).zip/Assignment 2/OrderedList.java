
package structures.linear;
 
/**
 * Lab1 Assignment
 * class OrderedList is book's example defined on page 167
 * Two methods which are solutions to P5.5. and P5.6 are added 
 * Kin Barksdale
 * 
 */
import java.util.ArrayList;
import java.util.NoSuchElementException;

public class OrderedList<T extends Comparable<T>>
{
    ArrayList<T> elements;
    int cursor;
    
    public OrderedList(int cap)
    {
        elements = new ArrayList<T>(cap);
        cursor = -1;
    }
    
    public OrderedList()
    {
        elements = new ArrayList<T>();
        cursor = -1;
    }
    
    public int size()
    {
        return elements.size();
    }
    
    public boolean isEmpty()
    {
        return elements.isEmpty();
    }
    
    public void clear()
    {
        elements.clear();
    }
    
    public T get(int pos)
    {
        if(pos < 0 || pos >= elements.size())
            throw new IndexOutOfBoundsException("pos < 0 or >= " + elements.size());
        return elements.get(pos);
    }
    
    public T first()
    {
        if(elements.size() == 0)
            return null;
        cursor = 0;
        return elements.get(cursor);
    }
    
    public T next()
    {
        if(cursor < 0 || cursor == (elements.size() - 1))
            return null;
        cursor++;
        return elements.get(cursor);
    }
    
    public int binarySearch(T item)
    {
        if(elements.size() == 0) // not found
        {
            return -1;
        }
        
        int lo = 0, hi = elements.size()-1;
        int mid = 0;
        
        while(lo <= hi)
        {
            mid = (lo+hi)/2;
            int c = item.compareTo(elements.get(mid));
            if(c == 0) return mid;
            if(c < 0) hi = mid - 1;
            else lo = mid + 1;
        }
        
        if(item.compareTo(elements.get(mid)) < 0)
        {
            return (-(mid+1));
        }
        else
            return (-(mid+2));
    }
    
    public void add(T item)
    {
        int pos = elements.size();
        if(pos > 0)
        {
            T pred = elements.get(pos -1);
            if(item.compareTo(pred) <= 0)
            {
                throw new OrderViolationException();
            }
        }
        elements.add(item);
    }
    
    public void add(int pos, T item)
    {
        if(pos < 0 || pos > elements.size())
        {
            throw new IndexOutOfBoundsException("pos < 0 or >= " + elements.size()+1);
        }
        if(pos > 0) {// there is a predecessor
            if(item.compareTo(elements.get(pos-1)) <= 0)
            {
                throw new OrderViolationException();
            }
        }
        elements.add(pos, item);
    }
    
    public void insert(T item)
    {
        if(elements.size() == 0)
        {
            elements.add(item);
            return;
        }
        int pos = binarySearch(item);
        if(pos >= 0){
            throw new OrderViolationException();
        }
        elements.add(-pos-1, item);
    }
    
    public void remove(T item)
    {
        if(elements.size() == 0)
        {
            throw new NoSuchElementException();
        }
        
        int pos = binarySearch(item);
        if(pos < 0)
        {
            throw new NoSuchElementException();
        }
        elements.remove(pos);
    }
    
    public void remove(int pos)
    {
        if(pos < 0 || pos >= elements.size())
        {
            throw new IndexOutOfBoundsException("pos < 0 or >= " + elements.size());
        }
        elements.remove(pos);
    }
    
    // this is the solution to P5.5
    public int lazyBinarySearch(T item)
    {
        int left = 0;
        int right = elements.size() - 1;
        int mid = 0;
        while(left < right)
        {
            mid = (left + right)/2;
            int c = item.compareTo(elements.get(mid));
            if(c > 0) left = mid + 1;
            else right = mid;
        }
        
        if(item.compareTo(elements.get(left)) == 0)
            return left;
        return -1;
    }
    
    // This is the solution to P5.6.
    public boolean blockSearch(T item)
    {
        int n = elements.size();
        if(n == 0) return false; // empty list
        int b = (int) Math.floor(Math.sqrt(n));
        int m = n/b;// divide into m blocks, each block has b elements. 
                    // It may have leftover.
        int k;
        for(k = 1; k <= m; ++k) // check last entries of m blocks
        {
            int c = item.compareTo(elements.get(k*b));
            if(c == 0) // find
                return true;
            else if(c < 0) 
                break;// in this case, if item is in list, it must be in kth block
        }
        if(k <= m) // item may be in kth block
        {
            for(int l = (k-1)*b+1; l < k*b; ++l)// check through kth block
            {
                if(item.compareTo(elements.get(l))==0) return true;
            }
        }
        else // check the leftover elements in the list
        {
            for(int j = m*b+1; j < n; ++j)// check through the leftover
            {
                if(item.compareTo(elements.get(j))==0) return true;
            }
        }
        return false;// not find
    }
}

