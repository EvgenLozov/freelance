package structures.linear;


/**
 * class OrderViolationException defined on page 182
 * 
 */
public class OrderViolationException extends RuntimeException
{
	public OrderViolationException()
	{
	    super();
	}
	
	public OrderViolationException(String s)
	{
	    super(s);
	}
}