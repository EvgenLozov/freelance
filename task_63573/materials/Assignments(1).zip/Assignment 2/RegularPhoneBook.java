

/**
 * Lab1 Assignment
 * class RegularPhoneBook part of solution for P5.4.
 * on page 187
 * @author Kin Barksdale
 * @version 1.3
 */
import structures.linear.OrderedList;
public class RegularPhoneBook
{
    OrderedList<RegularPhone> phoneList;
    
    public RegularPhoneBook()
    {
        phoneList = new OrderedList(100);
    }
    
    public void add(RegularPhone phone)
    {
        phoneList.add(phone);
    }
    
    public void insert(RegularPhone phone)
    {
        phoneList.insert(phone);
    }
    
    
    
    public void remove(RegularPhone phone)
    {
        phoneList.remove(phone);
    }
    
    // find phone number through name
    // notice that many people may have the same name
    // we return a string contain all phone numbers under the given name
    // all these phone numbers are separated by , and a space
    public String search(String name) 
    {
        RegularPhone phone = new RegularPhone(name, "000");
        int pos = phoneList.binarySearch(phone); // pos must less than 0
        int index = -1 - pos;// first position to start search
        String result = "";
        while(index < phoneList.size())
        {
            RegularPhone rp = phoneList.get(index);
            if(rp.getName().equals(name))
                result = result + rp.getNumber() + ", ";
            else break; // no more
            index++; // check next one on list
        }
        return result;
    }
}

