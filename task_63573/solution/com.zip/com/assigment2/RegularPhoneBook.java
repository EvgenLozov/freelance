package com.assigment2;

import com.assigment2.structures.linear.OrderedList;

/**
 * Lab1 Assignment
 * class RegularPhoneBook part of solution for P5.4.
 * on page 187
 * @author Kin Barksdale
 * @version 1.3
 */
public class RegularPhoneBook
{
    OrderedList<RegularPhone> phoneList;
    
    public RegularPhoneBook()
    {
        phoneList = new OrderedList(100);
    }
     //
    public int size()
    {
        return phoneList.size();
    }
    //
    public boolean isEmpty()
    {
        return phoneList.isEmpty();
    }
    //
    public void clear()
    {
        phoneList.clear();
    }
    
    //
    public void insert(RegularPhone phone)
    {
        phoneList.insert(phone);
    }
     //
    public RegularPhone get (int pos){
        return phoneList.get(pos);
    }
    //
    public RegularPhone first()
    {
        return phoneList.first();
    }
    //
    public RegularPhone next()
    {
        return phoneList.next();
    }
    //
    public void add(RegularPhone phone)
    {
        phoneList.add(phone);
    }
    //
    public void add(int pos, RegularPhone regularPhone)
    {
        phoneList.add(pos,regularPhone);
    }
    //
    public void remove(RegularPhone phone)
    {
        phoneList.remove(phone);
    }
    //
    public void remove (int pos){
        phoneList.remove(pos);
    }
    // find phone number through name
    // notice that many people may have the same name
    // we return a string contain all phone numbers under the given name
    // all these phone numbers are separated by , and a space
    public String search(String name)
    {
        RegularPhone phone = new RegularPhone(name, "000");
        int pos = phoneList.binarySearch(phone); // pos must less than 0
        int index = -1 - pos;// first position to start search
        String result = "";
        while(index < phoneList.size())
        {
            RegularPhone rp = phoneList.get(index);
            if(rp.getName().equals(name))
                result = result + rp.getNumber() + ", ";
            else break; // no more
            index++; // check next one on list
        }
        return result;
    }
     //
    public void display(){
        for (int i = 0; i<phoneList.size(); i++){
            System.out.println(phoneList.get(i).toString());
        }
        System.out.println("\n");
    }
}

