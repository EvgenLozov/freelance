 package com.assigment2;
/**
* Lab Assignment 1
* Driver program to test Phonebook application
* Kin Barksdale
*/

import java.util.Scanner;

public class UsePhoneBook {

	/**
	 * 
	 */
	public static void main(String[] args) 
	{
		String lname;
		String phonenbr;
		RegularPhone newphone;

		RegularPhoneBook austin = new RegularPhoneBook();
		
		Scanner scan = new Scanner (System.in);
		System.out.println("Enter a last name:\n");
		lname = scan.nextLine();
		
		while (!lname.equals("quit"))
		{
		System.out.println("Enter a phone number xxx-xxxx:\n");
		phonenbr = scan.nextLine();
		
		newphone = new RegularPhone(lname, phonenbr);

		//austin.add(newphone); // if you add a name out of order, you get EXception
		austin.insert(newphone);

		System.out.println("Enter a last name:\n");
		lname = scan.nextLine();
		}

        austin.display();
		
		
		
	}

}
