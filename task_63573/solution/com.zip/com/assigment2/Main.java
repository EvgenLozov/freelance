package com.assigment2;

import com.assigment2.structures.linear.OrderViolationException;

public class Main {
    public static void main(String[] args) {

        //create the phone book
        RegularPhoneBook phoneBook = new RegularPhoneBook();

        RegularPhone bobsPhone = new RegularPhone("Bob","1234565" );
        RegularPhone johnPhone = new RegularPhone("John","254-25489");
        RegularPhone pieterPhone = new RegularPhone("Pieter","254-25489");
        RegularPhone jackPhone = new RegularPhone("Jack","278-25489");

        //johnPhone1 is a duplicate of johnPhone
        RegularPhone johnPhone1 = new RegularPhone("John","254-25489");


        try{
            //add bob's phone
            System.out.println("Add Bob's phone to the phoneBook: "+bobsPhone);
            phoneBook.add(bobsPhone);

            //add John's phone
            System.out.println("Add John's phone to the phoneBook: "+johnPhone);
            phoneBook.add(johnPhone);

            //if you add a name out of order, you get Exception
            //for example add Pieter's phone
            System.out.println("Add Pieter's phone to the phoneBook: "+pieterPhone);
            phoneBook.add(johnPhone);

        } catch (OrderViolationException e) {
            System.out.println("You add a name out of order!");
        }

        try{
            //add Jack's phone
            System.out.println("Add John's phone to the phoneBook: "+jackPhone);
            phoneBook.add(4,jackPhone);

        }catch (IndexOutOfBoundsException e){
            System.out.println("Invalid position to add items!");
        }

        try {
            //insert Mary phone
            RegularPhone maryPhone = new RegularPhone("Mary","221-25489");
            System.out.println("Insert Mary phone to the phoneBook: "+maryPhone);
            phoneBook.insert(maryPhone);

            //insert a duplicate of johnPhone
            System.out.println("Add John's phone to the phoneBook: "+johnPhone1);
            phoneBook.insert(johnPhone1);
        } catch (OrderViolationException e) {
            System.out.println("You add the duplicate number in phoneBook!");
        }

        //output to screen the contents of the phoneBook
        System.out.println("Now the contents of the book");
        phoneBook.display();

        //get an element by index
        RegularPhone phoneByIndex = phoneBook.get(2);
        System.out.println("The element at index 2: "+phoneByIndex);

        //We will show all the items by phoneBook
        //without the use of the method display()
        //will use such methods for phoneBook: first() and next()
        int pos = 0;
        System.out.println(phoneBook.first());
        while (pos++ < phoneBook.size()-1)
            System.out.println(phoneBook.next());

        //search for items
        String name = "Bob";
        System.out.println("The subscriber with the name "+name+" has a phone  "+phoneBook.search(name));

        //remove phone
        System.out.println("Remove John's phone from the phoneBook");
        phoneBook.remove(johnPhone);
        System.out.println("Now the contents of the book");
        phoneBook.display();

        //remove phone by index
        int  removeIndex = 0;
        System.out.println("Remove phone with index "+removeIndex+" from the phoneBook");
        phoneBook.remove(removeIndex);
        System.out.println("Now the contents of the book");
        phoneBook.display();

        //clear the book if it is not empty
        if (!phoneBook.isEmpty()){
            System.out.println("Clear the book!");
            phoneBook.clear();
        }
        if (phoneBook.isEmpty())
            System.out.println("Now the phoneBook is empty.");

    }
}
