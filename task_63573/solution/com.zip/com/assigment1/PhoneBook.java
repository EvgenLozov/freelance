package com.assigment1;

import java.util.Arrays;

public class PhoneBook {
    //create the store RegularPhone objects
    private RegularPhone [] regularPhones;

    //current position to insert numbers
    private static int currentPosition =0;

    //rate of occupancy
    private static int loadFactor = 0;

    PhoneBook (int size){
        regularPhones = new RegularPhone[size];
    }

    //add regularPhone to phoneBook
    public void add(RegularPhone regularPhone){

        try {
            regularPhones[currentPosition++] = regularPhone;
            loadFactor++;
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Phonebook is full! \n" +
                    "To add a new number "+regularPhone.getName()+" "+regularPhone.getNumber()+", remove a number from the phone book.");
        }

        //after adding the numbers, we sort the array.
        Arrays.sort(regularPhones, 0, loadFactor);
    }

    //delete the number by Name
    public void remove(String namePhone){
        int position = -1;

        //determine the position of the remote numbers
        for (int i=0; i<loadFactor; i++){
            RegularPhone regularPhone = regularPhones[i];
            if (regularPhone.getName().equalsIgnoreCase(namePhone)){
                position = i;
                break;
            }
        }

        //
        if (position != -1){

            //We shifted all the elements of the array to the left.
            for (int i = position; i<loadFactor; i++){
                regularPhones[i] = regularPhones[i+1];
            }

            //current position for insert moved back
            currentPosition--;

            //number of phone declined in the phoneBook
            loadFactor--;
        }
    }

    //display the contents of the book to the screen.
    public void display(){

        for(int i = 0; i < loadFactor; i++)
        {
            System.out.println(regularPhones[i].toString());
        }

        System.out.println("\n");
    }

    public static void main(String[] args) {
        PhoneBook phoneBook = new PhoneBook(6);

        phoneBook.add(new RegularPhone("Tom","238-9999"));
        phoneBook.add(new RegularPhone("Bob","297-9999"));
        phoneBook.add(new RegularPhone("Walt ","256-9999"));
        phoneBook.add(new RegularPhone("Kathy ","237-9999"));
        phoneBook.add(new RegularPhone("Ann","239-9999"));

        phoneBook.display();

        phoneBook.remove("Bob");
        phoneBook.display();

        phoneBook.add(new RegularPhone("Mary","248-9999"));
        phoneBook.display();


    }

}
