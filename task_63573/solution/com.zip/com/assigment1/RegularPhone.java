 package com.assigment1;
/**
 * class RegularPhone part of the solution for P5.4
 * 
 * @author 
 * @version 
 */
public class RegularPhone extends Phone implements Comparable<RegularPhone>
{
    public RegularPhone(String name, String number)
    {
        super(name, number);
    }
    
    // To compare two phone, compare name first.
    // if names are the same, then compare the phone number
    public int compareTo(RegularPhone phone)
    {
        if(name.compareTo(phone.name) != 0)
            return name.compareTo(phone.name);
        return number.compareTo(phone.number);
    }
}