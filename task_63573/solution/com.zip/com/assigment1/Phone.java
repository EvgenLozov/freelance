package com.assigment1;

/**
 * Lab 1 assignment
 * class Phone defined for P5.2 and P5.4
 * on page 187
 * @author Kin Barksdale
 * @version 1.4
 */
public class Phone
{
	protected String name;
	protected String number;
	
	public Phone(String name, String number)
	{
	    this.name = name;
	    this.number = number;
	}
	
	public String getName()
	{
	    return name;
	}
	
	public String getNumber()
	{
	    return number;
	}
	
	public void setName(String name)
	{
	    this.name = name;
	}
	
	public void setNumber(String number)
	{
	    this.number = number;
	}
	
	public String toString()
	{
		return "Last name is " + name + " and phone number is " + number;
	}
	
	
	
}

